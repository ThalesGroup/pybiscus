from collections import OrderedDict
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple, Union

import flwr as fl
import numpy as np
import torch
import typer
from flwr.common import FitRes, Metrics, Parameters, Scalar
from flwr.server.client_proxy import ClientProxy
from lightning.fabric import Fabric
from omegaconf import OmegaConf
from torch.utils.data import DataLoader
from typing_extensions import Annotated

from src.console import console
from src.ml.registry import data_registry, model_registry
from src.flower.loops_fabric import test_loop


def set_params(model: torch.nn.ModuleList, params: List[np.ndarray]):
    params_dict = zip(model.state_dict().keys(), params)
    state_dict = OrderedDict({k: torch.from_numpy(np.copy(v)) for k, v in params_dict})
    model.load_state_dict(state_dict, strict=True)


def fit_config(server_round: int):
    """Return training configuration dict for each round."""
    config = {
        "server_round": server_round,  # The current round of federated learning
        "local_epochs": 1,  # if server_round < 2 else 2,  #
    }
    return config


def evaluate_config(server_round: int):
    """Return training configuration dict for each round."""
    config = {
        "server_round": server_round,  # The current round of federated learning
        # "local_epochs": 1,  # if server_round < 2 else 2,  #
    }
    return config


def get_evaluate_fn(
    testset,
    model,
    fabric,
) -> Callable[[fl.common.NDArrays], Optional[Tuple[float, float]]]:
    def evaluate(
        server_round: int, parameters: fl.common.NDArrays, config: Dict[str, Scalar]
    ) -> Optional[Tuple[float, float]]:
        set_params(model, parameters)

        loss, accuracy = test_loop(fabric=fabric, net=model, testloader=testset)
        console.log(f"Test loss: {loss}")
        return loss, {"Test loss": loss, "Test accuracy": accuracy}

    return evaluate


def weighted_average(metrics: List[Tuple[int, Metrics]]) -> Metrics:
    losses = [num_examples * m["loss"] for num_examples, m in metrics]
    examples = [num_examples for num_examples, _ in metrics]
    output = {
        # "accuracy": sum(accuracies) / sum(examples),
        "loss": sum(losses)
        / sum(examples),
    }
    console.log(f"Averaged metrics: {output}")
    return output


class SaveModelStrategy(fl.server.strategy.FedAvg):
    def __init__(
        self,
        *,
        model,
        fabric,
        evaluate_fn,
        fit_metrics_aggregation_fn,
        evaluate_metrics_aggregation_fn,
        on_fit_config_fn,
        on_evaluate_config_fn,
        fraction_fit: float = 1,
        fraction_evaluate: float = 1,
        min_fit_clients: int = 2,
        min_evaluate_clients: int = 2,
        min_available_clients: int = 2,
    ) -> None:
        super().__init__(
            evaluate_fn=evaluate_fn,
            fit_metrics_aggregation_fn=fit_metrics_aggregation_fn,
            evaluate_metrics_aggregation_fn=evaluate_metrics_aggregation_fn,
            fraction_fit=fraction_fit,
            fraction_evaluate=fraction_evaluate,
            min_fit_clients=min_fit_clients,
            min_evaluate_clients=min_evaluate_clients,
            min_available_clients=min_available_clients,
            on_fit_config_fn=on_fit_config_fn,
            on_evaluate_config_fn=on_evaluate_config_fn,
        )

        self.model = model
        self.fabric = fabric

    def aggregate_fit(
        self,
        server_round: int,
        results: List[Tuple[fl.server.client_proxy.ClientProxy, fl.common.FitRes]],
        failures: List[Union[Tuple[ClientProxy, FitRes], BaseException]],
    ) -> Tuple[Optional[Parameters], Dict[str, Scalar]]:
        """Aggregate model weights using weighted average and store checkpoint"""

        aggregated_parameters, aggregated_metrics = super().aggregate_fit(
            server_round, results, failures
        )

        # if aggregated_parameters is not None:
        #     print(f"Saving round {server_round} aggregated_parameters...")

        #     # Convert `Parameters` to `List[np.ndarray]`
        #     aggregated_ndarrays: List[np.ndarray] = fl.common.parameters_to_ndarrays(
        #         aggregated_parameters
        #     )

        #     # Convert `List[np.ndarray]` to PyTorch`state_dict`
        #     params_dict = zip(self.model.state_dict().keys(), aggregated_ndarrays)
        #     state_dict = OrderedDict({k: torch.tensor(v) for k, v in params_dict})
        #     self.model.load_state_dict(state_dict, strict=True)

        #     # Save the model
        #     new_path = f"../saved_models_path/model_round_{server_round}.pth"
        #     torch.save(self.model.state_dict(), new_path)

        return aggregated_parameters, aggregated_metrics


app = typer.Typer(pretty_exceptions_show_locals=False, rich_markup_mode="markdown")


@app.callback()
def server():
    """The server part of Hibiscus.

    Launch the server!
    """


@app.command()
def launch_config(
    config: Annotated[Path, typer.Argument()],
    num_rounds: int = None,
    device_num: int = None,
    data_dir_test: str = None,
    server_adress: str = None,
):
    """Launch a Flower Server.

    Args:
        num_rounds (int): number of rounds of FL
        device_num (int): the GPU index on which to run the server
    """
    if config is None:
        print("No config file")
        raise typer.Abort()
    if config.is_file():
        conf = OmegaConf.load(config)
        # console.log(conf)
    elif config.is_dir():
        print("Config is a directory, will use all its config files")
        raise typer.Abort()
    elif not config.exists():
        print("The config doesn't exist")
        raise typer.Abort()

    if num_rounds is not None:
        conf["num_rounds"] = num_rounds
    if device_num is not None:
        conf["device_num"] = device_num
    if data_dir_test is not None:
        conf["data_dir_test"] = data_dir_test
    if server_adress is not None:
        conf["server_adress"] = server_adress

    console.log(f"Conf specified: {conf}")

    fabric = Fabric(accelerator="gpu", devices=[conf["device_num"]])
    fabric.launch()
    _net = model_registry[conf["model"]["name"]](**conf["model"]["config"])
    net = fabric.setup_module(_net)
    _test_set = data_registry[conf["data"]["name"]](
        **conf["data"]["config"], stage="test"
    )
    test_set = fabric._setup_dataloader(_test_set)

    strategy = SaveModelStrategy(
        fraction_fit=1.0,
        fraction_evaluate=1.0,
        fit_metrics_aggregation_fn=weighted_average,
        evaluate_metrics_aggregation_fn=weighted_average,
        model=net,
        fabric=fabric,
        evaluate_fn=get_evaluate_fn(testset=test_set, model=net, fabric=fabric),
        on_fit_config_fn=fit_config,
        on_evaluate_config_fn=evaluate_config,
    )
    fl.server.start_server(
        server_address=conf["server_adress"],
        config=fl.server.ServerConfig(num_rounds=conf["num_rounds"]),
        strategy=strategy,
    )


if __name__ == "__main__":
    app()
